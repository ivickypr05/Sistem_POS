<nav id="navbar" class="navbar">
    <ul>
        <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
        <li><a class="nav-link scrollto" href="#tentang">Tentang</a></li>
        <li><a class="nav-link scrollto" href="#panduan">Panduan</a></li>
        <li><a class="nav-link scrollto" href="#fitur">Fitur</a></li>
        <li>
            <a class="getstarted scrollto" href="{{ route('login') }}">Login</a>
        </li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav>
