
<?php $__env->startSection('title', 'TBMJ | Halaman Produk Masuk'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="row">
            
            <div class="d-flex justify-content-end mb-1">
                <i class="fa-solid fa-arrows-up-down-left-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('home')); ?>" class="text-dark"> Dashboard</a>
                <i class="fa-solid fa-chevron-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('inproduct.index')); ?>" class="text-dark"> Produk Masuk</a>
            </div>
            <div class="card mt-1">
                <div class="card-header mt-2">
                    <h3 class="card-tittle">
                        <b>Daftar Produk Masuk</b>
                    </h3>
                </div>
                <br>
                <nav>
                    <div class='d-flex justify-content-start ms-2'>
                        <a href="<?php echo e(route('incart.index')); ?>" class="btn btn-success btn-md"><i class="fa fa-plus"></i>
                            Tambah</a>
                    </div>
                </nav>
                <br>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatablesSimple" class="table table-striped mt-1">
                                <thead>
                                    <tr>
                                        <th>
                                            <center>No</center>
                                        </th>
                                        <th>
                                            <center> Tanggal</center>
                                        </th>
                                        <th>
                                            <center> Nama Toko</center>
                                        </th>
                                        <th>
                                            <center> Total Item</center>
                                        </th>
                                        <th>
                                            <center>Aksi</center>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php $__currentLoopData = $inproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>
                                                <center><?php echo e($no++); ?>.</center>
                                            </th>
                                            <td><?php echo e(date('d M Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->nama_toko); ?></td>
                                            <td><?php echo e($item->total_item); ?></td>
                                            <td>
                                                <center>
                                                    <a href="<?php echo e(route('inproduct.show', $item->id)); ?>"
                                                        class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a></button>

                                                    <form id="deleteForm<?php echo e($item->id); ?>"
                                                        action="<?php echo e(route('inproduct.destroy', $item->id)); ?>" method="POST"
                                                        style="display:inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            onclick="event.preventDefault(); deleteConfirmation('<?php echo e($item->id); ?>');">
                                                            <i class="fas fa-trash"></i></button>
                                                    </form>
                                                </center>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function deleteConfirmation(itemId) {
            Swal.fire({
                title: 'Apakah yakin ingin menghapus?',
                text: "Item yang terhapus tidak bisa dikembalikan lagi!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Lakukan tindakan penghapusan
                    document.getElementById('deleteForm' + itemId).submit();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/inproduct/index.blade.php ENDPATH**/ ?>