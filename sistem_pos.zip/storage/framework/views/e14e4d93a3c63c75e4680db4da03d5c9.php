
<?php $__env->startSection('title', 'TBMJ | Halaman Detail Produk Masuk'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            
            <div class="d-flex justify-content-end mb-1">
                <i class="fa-solid fa-arrows-up-down-left-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('home')); ?>" class="text-dark"> Dashboard</a>
                <i class="fa-solid fa-chevron-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('inproduct.index')); ?>" class="text-dark"> Produk Masuk</a>
                <i class="fa-solid fa-chevron-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('inproduct.show', $inproduct->id)); ?>" class="text-dark"> Detail Produk Masuk</a>
            </div>
            <div class="card mt-2">
                <div class="card-body">
                    <h3><i class="fa fa-newspaper me-2"></i><b>Detail Produk Masuk</b></h3>
                    
                    <div class="card mt-4 mb-4 cetak-area">
                        <div class="card-body">
                            <table class="col-4" class="table table-bordered table-striped mt-1">
                                <tr>
                                    <td>Tanggal </td>
                                    <td>: <?php echo e($inproduct->created_at); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Toko </td>
                                    <td>: <?php echo e($inproduct->nama_toko); ?></td>
                                </tr>
                                <tr>
                                    <td>Total Item</td>
                                    <td>: <?php echo e($inproduct->total_item); ?></td>
                                </tr>
                            </table>
                            <br>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <center>
                                                <th>No</th>
                                                <th>Kode Produk</th>
                                                <th>Nama Produk</th>
                                                <th>Jumlah</th>
                                            </center>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php $__currentLoopData = $inproduct_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><span
                                                        style="background-color: #6daaf0; color: #fff; padding: 5px; border-radius: 0.25rem;"><?php echo e($item->kode_produk); ?></span>
                                                </td>
                                                <td><?php echo e($item->nama); ?></td>
                                                <td><?php echo e($item->jumlah); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/inproduct/detail.blade.php ENDPATH**/ ?>