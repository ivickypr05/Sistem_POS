<!-- Product Modal -->
<div class="modal fade" id="product_form" tabindex="-1" aria-labelledby="product_form" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="product_form"><b>Data Produk</b></h4>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table id="datatablesModal" class="table table-striped mt-1">
                        <thead>
                            <tr>
                                <th>
                                    <center>No</center>
                                </th>
                                <th>
                                    Kode Produk
                                </th>
                                <th>
                                    Nama Produk
                                </th>
                                <th>
                                    Stok
                                </th>
                                <th>
                                    Kategori
                                </th>
                                <th>
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th>
                                        <center><?php echo e($no++); ?>.</center>
                                    </th>
                                    <td><span
                                            style="background-color: #6daaf0;; color: #fff; padding: 5px; border-radius: 0.25rem;"><?php echo e($item->kode_produk); ?></span>
                                    </td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->stok); ?></td>
                                    <td><?php echo e($item->category->nama); ?></td>
                                    <td>
                                        <center>
                                            <form action="<?php echo e(route('incart.store')); ?>" method="POST"
                                                style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($item->id); ?>">
                                                <button type="submit" class="btn btn-success btn-sm">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </form>
                                        </center>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/inproduct/form.blade.php ENDPATH**/ ?>