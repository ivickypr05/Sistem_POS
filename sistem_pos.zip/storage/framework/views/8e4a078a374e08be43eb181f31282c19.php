<!-- Add Product Modal -->
<div class="modal fade" id="addForm" tabindex="-1" aria-labelledby="addForm" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="addForm"><b>Tambah Produk</b></h4>
            </div>
            <div class="modal-body">
                <form id="addProduct" action="<?php echo e(route('product.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="mb-1" for="kode_produk">Kode Produk</label>
                        <input type="text" class="form-control mb-2" id="kode_produk" name="kode_produk" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="nama">Nama Produk</label>
                        <input type="text" class="form-control mb-2" id="nama" name="nama" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="stok">Stok</label>
                        <input type="text" class="form-control mb-2" id="stok" name="stok" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="harga_beli">Harga Beli</label>
                        <input type="text" class="form-control mb-2" id="harga_beli" name="harga_beli" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="harga_jual">Harga Jual</label>
                        <input type="text" class="form-control mb-2" id="harga_jual" name="harga_jual" required>
                    </div>
                    <div class="form-group">
                        <label for="select" class="mb-1">Pilih Kategori</label>
                        <?php if($categories->isEmpty()): ?>
                            <div class="alert alert-warning" role="alert">
                                Data Kategori tidak Ditemukan!
                                <a href="<?php echo e(route('category.index')); ?>" class="alert-link">Isi Kategori</a>
                            </div>
                        <?php else: ?>
                            <select class="form-select" aria-label="Default select example" name="category_id" required>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="text-dark" value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary" form="addProduct">Simpan</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editForm" tabindex="-1" aria-labelledby="editForm" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="editForm"><b>Perbarui Produk</b></h4>
            </div>
            <div class="modal-body">
                <form id="editProduct" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label class="mb-1" for="kode_produk">Kode Produk</label>
                        <input type="text" class="form-control mb-2" id="edit_kode_produk" name="kode_produk"
                            required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="nama">Nama Produk</label>
                        <input type="text" class="form-control mb-2" id="edit_nama" name="nama" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="stok">Stok</label>
                        <input type="text" class="form-control mb-2" id="edit_stok" name="stok" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="harga_beli">Harga Beli</label>
                        <input type="text" class="form-control mb-2" id="edit_harga_beli" name="harga_beli"
                            required>
                    </div>
                    <div class="form-group">
                        <label class="mb-1" for="harga_jual">Harga Jual</label>
                        <input type="text" class="form-control mb-2" id="edit_harga_jual" name="harga_jual"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="select" class="mb-1">Pilih Kategori</label>
                        <select class="form-select" aria-label="Default select example" id="edit_category_id"
                            name="category_id" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary" form="editProduct">Simpan</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/product/form.blade.php ENDPATH**/ ?>