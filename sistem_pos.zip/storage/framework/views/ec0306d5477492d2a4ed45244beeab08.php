<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="form login">
        <?php echo csrf_field(); ?>
        <div class="form__field">
            <label for="email">
                <i class="bi bi-envelope"></i>
                <span class="hidden">Alamat Email</span>
            </label>
            <div class="input-wrapper">
                <input id="email" type="email" name="email" class="form__input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Email" required autocomplete="email" autofocus>
                
            </div>
        </div>


        <div class="form__field">
            <label for="password">
                <i class="bi bi-key-fill"></i>
                <span class="hidden">Alamat password</span>
            </label>
            <div class="input-wrapper">
                <input id="password" type="password" name="password"
                    class="form__input  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required
                    autocomplete="current-password">
                <i class="bi bi-eye-fill toggle-password"></i>
                
            </div>
        </div>
        <div class="form__field row">
            <input type="submit" value="Login">
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const togglePassword = document.querySelector('.toggle-password');
        const passwordInput = document.querySelector('#password');

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('bi-eye-fill');
            this.classList.toggle('bi-eye-slash-fill');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\sistem_pos\resources\views/auth/login.blade.php ENDPATH**/ ?>