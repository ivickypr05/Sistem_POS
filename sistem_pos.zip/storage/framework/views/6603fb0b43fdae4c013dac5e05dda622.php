
<?php $__env->startSection('title', 'TBMJ | Dashboard Kasir'); ?>
<?php $__env->startSection('content'); ?>
    <p>sadas</p>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/homekasir.blade.php ENDPATH**/ ?>