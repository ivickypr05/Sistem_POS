<?php $__env->startSection('title', 'TBMJ | Halaman Riwayat Transaksi'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="row">
            
            <div class="d-flex justify-content-end mb-1">
                <i class="fa-solid fa-arrows-up-down-left-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('home')); ?>" class="text-dark"> Dashboard</a>
                <i class="fa-solid fa-chevron-right mt-1 ms-2 mb-1 me-2"></i>
                <a href="<?php echo e(route('transaction.all')); ?>" class="text-dark"> Riwayat Transaksi</a>
            </div>
            <div class="card mt-1">
                <div class="card-header mt-2">
                    <h3 class="card-tittle">
                        <b>Daftar Riwayat Transaksi</b>
                    </h3>
                </div>
                <br>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatablesSimple" class="table table-striped mt-1">
                                <thead>
                                    <tr>
                                        <th>
                                            <center>No</center>
                                        </th>
                                        <th>
                                            <center> Tanggal</center>
                                        </th>
                                        <th>
                                            <center> Nomor Invoice</center>
                                        </th>
                                        <th>
                                            <center> Nama User</center>
                                        </th>
                                        <th>
                                            <center> Total Harga</center>
                                        </th>
                                        <th>
                                            <center> Total Pembayaran</center>
                                        </th>
                                        <th>
                                            <center> Kembalian</center>
                                        </th>
                                        <th>
                                            <center>Aksi</center>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>
                                                <center><?php echo e($no++); ?>.</center>
                                            </th>
                                            <td><?php echo e(date('d M Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->invoice_nomor); ?></td>
                                            <td><?php echo e($item->user->name); ?></td>
                                            <td>Rp<?php echo e(number_format($item->total_harga)); ?></td>
                                            <td>Rp<?php echo e(number_format($item->jumlah_bayar)); ?></td>
                                            <td>Rp<?php echo e(number_format($item->jumlah_bayar - $item->total_harga)); ?></td>
                                            <td>
                                                <center>
                                                    <a href="<?php echo e(route('transaction.show', $item->id)); ?>"
                                                        class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a></button>
                                                </center>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\applications\sistem_pos\resources\views/dashboard/transaction/all.blade.php ENDPATH**/ ?>